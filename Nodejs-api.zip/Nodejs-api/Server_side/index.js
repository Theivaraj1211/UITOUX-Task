const express = require('express');
const dotenv = require('dotenv').config();
const cors = require('cors');
const { mongoose } = require('mongoose');
const productRoute = require('./routes/productRoutes')
const productTypeRoutes = require('./routes/productTypeRoutes');

mongoose.connect(process.env.MONGO_URL)
    .then(() => console.log('Database Coonected'))
    .catch((err) => console.log('Database not connected', err))

const app = express();
const port = 4000;
app.use(express.json())
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Content-Type', 'application/json');
    next();
});
app.use('/api/v1/product', productRoute);
app.use('/api/v1/productType', productTypeRoutes);
app.listen(port, () => {
    console.log(`server started on ${port}`)
})